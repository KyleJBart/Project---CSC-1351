package prog01_aorderedlist;

import java.util.NoSuchElementException;

/**
 *
 * @author kylebarthelemy
 */
public class aOrderedList 
{
    final int SIZEINCREMENTS = 20; //Size of increments for increasing ordered list
    
    private Car[] oList; //ordered list
    private int listSize; //size of the ordered list
    private int numObjects;
    private int curr; //number of objects in the ordered list
    
    public aOrderedList() //Constructor method
    {
        this.numObjects = 0;
        this.listSize = SIZEINCREMENTS;
        this.oList = new Car[SIZEINCREMENTS];
    }
    
    public void add(Car newCar) //Adds another car object when called, if list is full, increase the size of the list before doing so
    {
        
        if(numObjects == listSize)
        {
            Car[] newList = new Car[listSize + SIZEINCREMENTS];
            System.arraycopy(oList, 0, newList, 0, listSize);
            oList = newList;
            listSize += SIZEINCREMENTS;
        }
        oList[numObjects++] = newCar;
       
    }    
    @Override
    public String toString() 
    {
        StringBuilder newString = new StringBuilder("[");
        newString.toString();
        newString.append("]");
        return newString.toString();
    }
    
    public int size() //Returns the size of the array
    {
        return numObjects;
    }
    
    public Car get(int index) //Returns the index of a Car object that the user determines
    {
        if(index >= numObjects || index < 0)
        {
            throw new ArrayIndexOutOfBoundsException("Index: " + index + ", Size: " + numObjects);
        }
        return oList[index];
    }
    
    public boolean isEmpty() //Returns true if the the array is not full aka numObjects is set to 0
    {
        if(numObjects == 0)
        {
            return true;
        }
        else
            return false;
    }
    
    public void remove(int index) //Removes the car object that the user determines
    {
        if(index >= numObjects || index < 0)
        {
            throw new ArrayIndexOutOfBoundsException("Index: " + index + ", Size: " + numObjects);
        }
        for (int i = index; i < numObjects - 1; i++) 
        {
            oList[i] = oList[i + 1];
        }

        // Set the last element to null to avoid memory leaks
        oList[numObjects - 1] = null;
        numObjects--;
        
    }
    
    public void reset()
    {
        curr = -1;
        
    }
    
    public Comparable next()
    {
        if(hasNext())
        {
            curr++;
            Comparable next = oList[curr];
            return next;
        }
        else
        {
            throw new NoSuchElementException("Element does not exist.");
        }
    }
    
    public boolean hasNext()
    {
        return curr < numObjects;
    }
    
    public void remove()
    {
        if(curr > 0 && curr <= numObjects)
        {
            remove(curr-1);
        }
    }
            
}
