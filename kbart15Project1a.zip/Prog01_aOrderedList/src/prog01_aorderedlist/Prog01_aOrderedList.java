package prog01_aorderedlist;

/**
 * CSC 1351 Programming Project No 1
 * Section 2
 * @author Kyle Barthelemy
 * @since 3/17/24
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;

public class Prog01_aOrderedList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException
    {
       Scanner in = GetInputFile("Enter input filename: "); 
       
       aOrderedList orderedList = new aOrderedList();
       
       /**
        * Checks the input file's line to make sure the length of the information is equal to 4 and
        * then determines what the first letter of the sequence is. If the letter is A, it takes the
        * make, year, and price, and adds it into the newCar object that is then extracted onto the 
        * ordered list. If the letter is D, the index of that Car's information is then taken and
        * removed using the remove method.
        */ 
      
       while(in.hasNextLine()) 
       {
           String info = in.nextLine();
           String[] carDet = info.split(",");
           if(carDet.length == 4)
           {
               if(carDet[0].equals("A"))
               {
                   String make = carDet[1];
                   int year = Integer.parseInt(carDet[2]);
                   int price = Integer.parseInt(carDet[3]);
                   
                   Car newCar = new Car(make, year, price);
                   orderedList.add(newCar);
                   
               }
               else if (carDet[0].equals("D"))
               {
                   int index = Integer.parseInt(carDet[1]);
                   orderedList.remove(index);
               }
            }
        }
       
       
        /**
         * Prints out the final number of cars after all were added and then removed
         * in a special format that makes it easy to read.
         */
        //PrintWriter output = GetOutputFile("Enter output filename: ");
        
        System.out.println("Number of Cars: " + orderedList.size());
        System.out.println();
        for (int i = 0; i < orderedList.size(); i++)
        {
            Car myCar = orderedList.get(i);
            System.out.println("Make: " + myCar.getMake());
            System.out.println("Year: " + myCar.getYear());
            System.out.println("Price: $" + myCar.getPrice());
            System.out.println();
        }
    }

    public static Scanner GetInputFile (String UserPrompt) throws FileNotFoundException
    {

        Scanner userPrompt = new Scanner(System.in);
        System.out.print("Enter input filename: ");
        String fileName = userPrompt.nextLine();
        
        File carInfo = new File("CarInfo.txt");
        Scanner carFile = new Scanner(carInfo);
        while(!fileName.equals("CarInfo.txt"))
        {
            System.out.print("File specified <" + userPrompt + "> does not exist.\n Would you like to continue? <Y/N> ");
                    
            if(userPrompt.nextLine().equalsIgnoreCase("Y"))
            {
                System.out.print("Enter input filename: ");
                fileName = userPrompt.nextLine();
            }
            else if (userPrompt.nextLine().equalsIgnoreCase("N"))
            {
                System.out.print("Type either Y or N to the question above.");
                throw new FileNotFoundException("File not found.");
            }
            else
            {
                System.out.print("Type either Y or N to the question above.");
            }
                
        }
        userPrompt.close();
        return carFile;
    }
    
    
    public PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException
    {
       System.out.print("Enter output file: ");
       Scanner userPrompt = new Scanner(System.in);
       String fileName = userPrompt.nextLine();
       PrintWriter output = new PrintWriter("Output.txt");
       
       while(!fileName.equals("Output.txt"))
       {
           System.out.print("File specified <" + userPrompt + "> does not exist.\n Would you like to continue? <Y/N>");
           
           if(userPrompt.nextLine().equals("Y"))
           {
               System.out.print("Enter output filename: ");
               fileName = userPrompt.nextLine();
           }
           else if(userPrompt.nextLine().equalsIgnoreCase("N"))
           {
               throw new FileNotFoundException("File not found.");
           }
           else
           {
               System.out.print("Enter Y or N to the question above. ");
           }
       }
       userPrompt.close();
       return output;
       
       
       
    } 
}    
