package prog01_aorderedlist;

/**
 *
 * @author kylebarthelemy
 */
public class Car implements Comparable<Car>
{
    private String make; //make of car
    private int year; //year of car
    private int price; //price of car
    
    public Car (String make, int year, int price) 
    {
        this.make = make;
        this.year = year;
        this.price = price;
    }
    
    public String getMake() //returns the make of the car
    {
        return make;
    }
    
    public int getYear() //returns the year of the car
    {
        return year;
    }
    
    public int getPrice() //returns the price of the car
    {
        return price;
    }
    
    @Override
    public int compareTo(Car other) //Compares cars by make first and if they are the same then it compares by their year
    {
        int makeComparison = this.make.compareTo(other.make);
        if (makeComparison != 0)
            return makeComparison;
        else 
        {
            int yearComparison = Integer.compare(this.year ,other.year);
            return yearComparison;
        }
    }
    
    @Override
    public String toString()
    {
        return "Make: " + make + ", Year: " + year + ", Price: " + price + ";";
    }
    
    
    
    
}
